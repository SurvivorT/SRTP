from rllab.core.parameterized import Parameterized


class QFunction(Parameterized):
    pass
